scp -r -P 4022 dforero@localhost:/hpcstorage/dforero/projects/baosystematics/results/nosyst_v7/baofit/avg_combined_void/TwoPCF_mockavg_nosyst_v7_void_R-15.5-50_cbz_triplot.pdf .
scp -r -P 4022 dforero@localhost:/hpcstorage/dforero/projects/baosystematics/results/allsyst_v7/baofit/avg_combined_void/TwoPCF_mockavg_allsyst_v7_void_R-15.5-50_cbz_triplot.pdf .
scp -r -P 4022 dforero@localhost:/hpcstorage/dforero/projects/baosystematics/results/nosyst_v7/baofit/avg_combined_gal/ELG_ALL_bin8_mean_xi0_triplot.pdf TwoPCF_mockavg_nosyst_v7_gal_cbz_triplot.pdf 
scp -r -P 4022 dforero@localhost:/hpcstorage/dforero/projects/baosystematics/results/allsyst_v7/baofit/avg_combined_gal/ELG_ALL_bin8_mean_xi0_triplot.pdf TwoPCF_mockavg_allsyst_v7_gal_cbz_triplot.pdf 
